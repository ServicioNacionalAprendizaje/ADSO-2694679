package com.sena.corritobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorritoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
