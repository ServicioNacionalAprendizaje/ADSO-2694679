package com.sena.corritobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorritoBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorritoBackendApplication.class, args);
	}

}
