package com.sena.servicesecurity.DTO;

public interface IViewDto extends IGenericDto{

	String getName();
	String getDescription();
	String getRoute();
}
