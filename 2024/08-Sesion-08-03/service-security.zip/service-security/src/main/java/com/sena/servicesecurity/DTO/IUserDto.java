package com.sena.servicesecurity.DTO;

public interface IUserDto extends IGenericDto {

	String getUser();
	String getPersonName();
	String getPersonEmail();
}
