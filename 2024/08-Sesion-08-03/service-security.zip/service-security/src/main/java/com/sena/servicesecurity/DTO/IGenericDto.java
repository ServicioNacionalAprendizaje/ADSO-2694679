package com.sena.servicesecurity.DTO;

public interface IGenericDto {

	Long getId();
	Boolean getState();
}
