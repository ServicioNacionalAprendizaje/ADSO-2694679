package com.sena.servicesecurity.DTO;

public interface IModuleDto extends IGenericDto{


	String getModule();
	String getDescription();
	String getRoute();
}
