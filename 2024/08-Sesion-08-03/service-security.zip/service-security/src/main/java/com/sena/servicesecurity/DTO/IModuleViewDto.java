package com.sena.servicesecurity.DTO;

public interface IModuleViewDto extends IGenericDto{


	String getPerson();
}
