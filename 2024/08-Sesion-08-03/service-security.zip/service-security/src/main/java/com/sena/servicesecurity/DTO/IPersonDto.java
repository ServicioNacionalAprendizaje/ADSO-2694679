package com.sena.servicesecurity.DTO;

public interface IPersonDto extends IGenericDto{


	String getPerson();
}
