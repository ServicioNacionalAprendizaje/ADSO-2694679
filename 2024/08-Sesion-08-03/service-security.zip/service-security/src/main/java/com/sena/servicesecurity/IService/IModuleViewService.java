package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.ModuleView;

public interface IModuleViewService extends IBaseService<ModuleView>{

}
