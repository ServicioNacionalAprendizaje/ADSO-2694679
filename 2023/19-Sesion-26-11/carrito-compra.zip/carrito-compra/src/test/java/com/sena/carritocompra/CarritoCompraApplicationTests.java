package com.sena.carritocompra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarritoCompraApplicationTests {

	@Test
	void contextLoads() {
	}

}
